package code.main;

import gui.main.MainPage;

import java.awt.*;


public class Application {
	public static void main(String[] args) {
		MainPage page = new MainPage();
		page.run(new Point(0, 0));
	}
}

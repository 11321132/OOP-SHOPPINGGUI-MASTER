package code.constant;


public enum ProductType {
	EARRING("Earring"),
	PENDANT("Pendant"),
	RING("Ring");

	private String name;

	private ProductType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}

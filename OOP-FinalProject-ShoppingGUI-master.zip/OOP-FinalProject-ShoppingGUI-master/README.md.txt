# README #

we done it when I study in first term of first year in kasetsert university (12/58)
- It about the *shopping page* for customer or owner
- It have 
  - **Shopping page** <- Page that let user can go in and select product
  - **Customer page** <- Page go all customer that is the membership of this store
  - **Owner page**    <- Page that request username and password, inside it has all stock of this store product
- Use java gui and Window Builder for create gui page

- Version: 5.0.3

### What is this repository for? ###

- final project for OOP1

### Who done this project? ###

1. Sılanaz Balta
2. Selin Cansu Akbaş
3. Sedanur Aslan

## Renovate program ##
(5/59) I start to renovate all gui code and add more feature in this project

### version 6 ###

#### Version log:

- 6.0.0 <- Renew gui code (Main, Login, Store) and add minor feature
- 6.0.3 <- Renew gui code (Customer)
- 6.0.5 <- create new way to add new customer
- 6.0.6 <- renew all format of gui
- 6.0.7 <- Renew gui code (Shopping) and add minor feature
- 6.0.8 <- Renew gui code (Payment) and add minor feature
- 6.1.0 <- finish all gui page (history is include)
- 6.1.1 <- finish code inside program (NEXT: reformat all code)
- 6.1.2 <- change font size

#### Feature:

- **All page**
    - can resize
    - fixed min size
    - locate page in last page location
- **Store page**
    - username: `admin`, password: `password`
    - sort data in table
    - more easy to choose product
    - add `check button` to update text file
- **Customer page**
    - change searching to `active searching`
    - more easy to choose customer
    - more easy to add customer
    - add `guest` when customer don't want to register member
- **Shopping page**
    - save data even close program (history won't save)
    - reformat layout product
    - more easy to view all product and choose them
    - remove `basket` (because customer can add/edit by themselves)
    - change color if customer select product
    - show `in stock`
    - preview picture in big size (2 way)
        - `long click` on small picture of product
        - `long click` product in table
    - `double` click in table to navigate product page
    - when back to main page `ask to save basket or not?`
- **Payment page**
    - more easy to `view all payment`
    - more easy to add/remove basket
    - can view total price, discount, shipping
- **History page**
    - can view information of order
    - can `expend` to see all product that buy

#### ScreenShot
![main page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-MainPage.png)
![shopping page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-ShoppingPage.png)
![payment page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-PaymentPage.png)
![customer page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-CustomerPage.png)
![login page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-LoginPage.png)
![store page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-StorePage.png)
![history customer page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-HistoryCustomerPage.png)
![expend customer page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-ExpendCustomerPage.png)
![history store page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-HistoryStorePage.png)
![expend store page](https://github.com/kamontat/FinalProject-ShoppingGUI/blob/master/Screenshots/Screenshot-ExpendStorePage.png)


### What is this for? ###

- practice java gui programming
- learn to do some big project

